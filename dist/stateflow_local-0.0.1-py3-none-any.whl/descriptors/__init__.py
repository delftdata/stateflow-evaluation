from src.descriptors.class_descriptor import ClassDescriptor, MethodDescriptor
from src.descriptors.method_descriptor import (
    InputDescriptor,
    OutputDescriptor,
)
